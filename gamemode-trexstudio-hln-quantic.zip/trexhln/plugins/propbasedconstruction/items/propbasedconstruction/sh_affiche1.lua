ITEM.name = "Affiche de Propagande n°1"
ITEM.description = "Une affiche de propagande"
ITEM.category = "Constructable"
ITEM.model = "models/cmz/combinev2.mdl"
ITEM.prop = "models/cmz/combinev2.mdl"
ITEM.width = 2
ITEM.height = 3
