ITEM.name = "Munitions de SMG"
ITEM.model = "models/Items/BoxSRounds.mdl"
ITEM.ammo = "smg1" -- type of the ammo
ITEM.ammoAmount = 45 -- amount of the ammo
ITEM.description = "Cette boite contient %s munitions de SMG"
ITEM.category = "Munitions"
ITEM.flag = "V"
