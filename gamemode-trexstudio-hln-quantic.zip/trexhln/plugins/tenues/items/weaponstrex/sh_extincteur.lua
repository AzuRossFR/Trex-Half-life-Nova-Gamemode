ITEM.name = "Extincteur"
ITEM.model = "models/weapons/w_fire_extinguisher.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 11 
ITEM.class = "weapon_extinguisher_infinite"
ITEM.description = [[Appareil capable d'éteindre un feu d'incendie par projection d'une substance sous pression.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_AMNESIC -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )