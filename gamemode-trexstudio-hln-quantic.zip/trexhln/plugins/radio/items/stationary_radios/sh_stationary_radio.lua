ITEM.name = "Radio stationnaire"
ITEM.description = "Une radio stationnaire est équipée d'un syntoniseur de fréquence.."
ITEM.model = "models/props_lab/citizenradio.mdl"
ITEM.category = "Communication"
ITEM.cost = 1200
ITEM.tuningEnabled = true
