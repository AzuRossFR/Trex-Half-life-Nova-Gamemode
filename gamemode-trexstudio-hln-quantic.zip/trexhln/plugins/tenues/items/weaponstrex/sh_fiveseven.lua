ITEM.name = "Five-seveN"
ITEM.model = "models/props_junk/cardboard_box001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "tfa_fml_five_seven"
ITEM.description = [[Le Five-seveN est un pistolet semi-automatique conçu par la société belge FN Herstal. 

Il tire la cartouche 5,7x28 mm, est connu pour sa légèreté, sa capacité de chargeur élevée et sa précision.
]]
ITEM.category = "TrexStudio"
ITEM.weight = 0.800
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMES
