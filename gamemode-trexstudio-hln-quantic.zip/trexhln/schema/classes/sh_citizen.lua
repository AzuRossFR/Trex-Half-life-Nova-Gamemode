CLASS.name = "Citizen"
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = true
CLASS_CITIZEN = CLASS.index