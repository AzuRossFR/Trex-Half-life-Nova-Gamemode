ITEM.name = "Red Couch"
ITEM.description = "A Red Couch."
ITEM.category = "Constructable"
ITEM.model = "models/Items/item_item_crate.mdl"
ITEM.prop = "models/props_c17/FurnitureCouch001a.mdl"
ITEM.width = 2
ITEM.height = 2
