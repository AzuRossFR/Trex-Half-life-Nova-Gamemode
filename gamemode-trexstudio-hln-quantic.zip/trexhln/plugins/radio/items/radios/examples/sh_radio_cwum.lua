
ITEM.name = "Union Medical Radio"
ITEM.description = "An encrypted radio branded with the UM logo, permanently tuned to the Union Medical subchannel."
ITEM.frequency = "um"
ITEM.frequencyID = "freq_cwum"
ITEM.stationaryCanAccess = false
