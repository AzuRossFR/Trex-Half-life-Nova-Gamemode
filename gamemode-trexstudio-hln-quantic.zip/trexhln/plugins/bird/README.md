Adds a bird faction.
## Installation
* Download the zip
* Extract the zip into your schemas plugin folder

## Features
* Bird faction
* Administrator config, easily change how birds work
