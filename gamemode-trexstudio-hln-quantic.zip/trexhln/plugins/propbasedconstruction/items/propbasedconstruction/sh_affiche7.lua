ITEM.name = "Affiche de Propagande n°7"
ITEM.description = "Une affiche de propagande"
ITEM.category = "Constructable"
ITEM.model = "models/cmz/combinev8.mdl"
ITEM.prop = "models/cmz/combinev8.mdl"
ITEM.width = 2
ITEM.height = 3
