
STATION.name = "Établi"
STATION.description = "Un établi utilisé pour l'artisanat."
STATION.model = "models/props_wasteland/controlroom_desk001b.mdl"
