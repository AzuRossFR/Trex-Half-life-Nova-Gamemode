CLASS.name = "Elite Metropolice"
CLASS.faction = FACTION_MPF
CLASS.isDefault = false
CLASS_EMP = CLASS.index
