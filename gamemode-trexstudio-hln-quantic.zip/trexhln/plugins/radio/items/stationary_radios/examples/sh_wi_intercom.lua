
ITEM.name = "UIL Intercom"
ITEM.description = "A small phone with a base, linked internally to other Union Innovation Labs intercom devices."
ITEM.model = "models/props_office/office_phone.mdl"
ITEM.category = "Communication"
ITEM.frequencyID = "intercom_uil"
