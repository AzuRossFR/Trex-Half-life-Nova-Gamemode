
ITEM.name = "CAB Radio"
ITEM.description = "A special encrypted radio that is biolocked. Only CAB members and OTA can use it."
ITEM.frequency = "CAB"
ITEM.frequencyID = "cab"
ITEM.factionLock = {
	--[FACTION_SRVADMIN] = true,
	--[FACTION_ADMIN] = true,
	[FACTION_OTA] = true
}
