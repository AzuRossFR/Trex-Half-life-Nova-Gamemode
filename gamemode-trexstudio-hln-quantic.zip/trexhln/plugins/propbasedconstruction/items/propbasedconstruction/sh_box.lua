ITEM.name = "Tableau de Wallace Breen"
ITEM.description = "Un tableau de l'administrateur de la terre."
ITEM.category = "Constructable"
ITEM.model = "models/willardnetworks/posters/wn_portrait_3.mdl"
ITEM.prop = "models/willardnetworks/posters/wn_portrait_3.mdl"
ITEM.width = 2
ITEM.height = 2
