ENT.Type = "anim"
ENT.Author = "heRn (ds : hern9)"
ENT.PrintName = "Poubelle"
ENT.Category = "Hobo Love"
ENT.Spawnable = true
ENT.AdminSpawnable = true