ITEM.name = "Grand Sac Militaire"
ITEM.description = [[Un grand sac qui vous permettra de stocker beaucoup d'objets mais qui vous ralentira en contrepartie.
]]
ITEM.model = "models/eft_props/gear/backpacks/bp_6sh118.mdl"
ITEM.bonemerge = "models/eft_modular/gear/backpacks/6sh118.mdl"
ITEM.category = "TrexSac"
ITEM.width = 2
ITEM.height = 2
ITEM.invWidth = 5
ITEM.rarity = 4
ITEM.rarityname = "Légendaire"
ITEM.invHeight = 4
ITEM.isBag = true
ITEM.weight = 1
ITEM.attachement = "hips"
ITEM.noBusiness = true