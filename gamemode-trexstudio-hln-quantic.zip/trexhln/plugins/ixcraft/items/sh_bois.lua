ITEM.name = "Bois"
ITEM.model = Model("models/Gibs/wood_gib01e.mdl")
ITEM.description = "Un bout de bois qui peut servir de manche."
ITEM.category = "TrexCraft"