PLUGIN.name = "Trash Entity"
PLUGIN.author = "Hern"
PLUGIN.description = "A simple entity that remove shit."