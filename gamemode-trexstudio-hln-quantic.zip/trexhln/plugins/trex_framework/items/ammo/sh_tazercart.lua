ITEM.name = "Cartouches de Taser"
ITEM.model = "models/sterling/enhanced_taser_ammobox.mdl"
ITEM.ammo = "stungun" -- type of the ammo
ITEM.ammoAmount = 5 -- amount of the ammo
ITEM.description = "Cette boite contient %s cartouches de Taser."
ITEM.category = "Munitions"
