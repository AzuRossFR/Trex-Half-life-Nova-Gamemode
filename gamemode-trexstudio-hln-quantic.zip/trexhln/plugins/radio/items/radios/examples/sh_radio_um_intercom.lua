
ITEM.name = "Medical Intercom Radio"
ITEM.description = "An encrypted radio branded with the UM logo, permanently tuned to the Medical intercom system."
ITEM.frequency = "um intercom"
ITEM.frequencyID = "intercom_um"
