
FACTION.name = "Protection Civile"
FACTION.description = "A metropolice unit working as Civil Protection."
FACTION.color = Color(86, 107, 102)
FACTION.pay = 10
FACTION.image = ix.util.GetMaterial("trex/bannierefaction/pc_ban.png")
FACTION.icon = ix.util.GetMaterial("trex/logo/icon_pc.png")
FACTION.models = {
		{"models/earl_rp/citizens/player/male_01.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_02.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_03.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_04.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_05.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_06.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_07.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_08.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/male_09.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_01.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_02.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_04.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_06.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_19.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_bms_1.mdl",0,"00000"},
		{"models/earl_rp/citizens/player/female_bms_2.mdl",0,"00000"},
	}
FACTION.weapons = {"ix_stunstick"}
FACTION.isDefault = false
FACTION.isGloballyRecognized = true
FACTION.runSounds = {[0] = "NPC_MetroPolice.RunFootstepLeft", [1] = "NPC_MetroPolice.RunFootstepRight"}
FACTION.listenChannels = {
	["cp_main"] = 1,
	["overwatch"] = 1,
}

FACTION.taglines = {
	"union",
    "defender",
    "king",
    "line",
    "quick",
    "roller",
    "stick",
    "tap",
    "victor",
	"xray"
}

function FACTION:GetDefaultName(ply)
	return "c24:RcE°" .. string.upper(self.taglines[math.random(1, #self.taglines)]) .. "." .. Schema:ZeroNumber(math.random(100, 999), 3), true
end

function FACTION:OnCharacterCreated(client, character)
	local inventory = character:GetInventory()

	inventory:Add("pistol", 1)
	inventory:Add("pistolammo", 2)
end

function FACTION:OnTransferred(character)
	character:SetName(self:GetDefaultName())
	character:SetModel(self.models[1])
end

function FACTION:OnNameChanged(client, oldValue, value)
	local character = client:GetCharacter()

	if (!Schema:IsCombineRank(oldValue, "RCT") and Schema:IsCombineRank(value, "RCT")) then
		character:JoinClass(CLASS_MPR)
	elseif (!Schema:IsCombineRank(oldValue, "OfC") and Schema:IsCombineRank(value, "OfC")) then
		character:SetModel("models/policetrench.mdl")
	elseif (!Schema:IsCombineRank(oldValue, "EpU") and Schema:IsCombineRank(value, "EpU")) then
		character:JoinClass(CLASS_EMP)

		character:SetModel("models/leet_police2.mdl")
	elseif (!Schema:IsCombineRank(oldValue, "DvL") and Schema:IsCombineRank(value, "DvL")) then
		character:SetModel("models/eliteshockcp.mdl")
	elseif (!Schema:IsCombineRank(oldValue, "SeC") and Schema:IsCombineRank(value, "SeC")) then
		character:SetModel("models/sect_police2.mdl")
	elseif (!Schema:IsCombineRank(oldValue, "SCN") and Schema:IsCombineRank(value, "SCN")
	or !Schema:IsCombineRank(oldValue, "SHIELD") and Schema:IsCombineRank(value, "SHIELD")) then
		character:JoinClass(CLASS_MPS)
	end

	if (!Schema:IsCombineRank(oldValue, "GHOST") and Schema:IsCombineRank(value, "GHOST")) then
		character:SetModel("models/eliteghostcp.mdl")
	end
end

FACTION_MPF = FACTION.index
