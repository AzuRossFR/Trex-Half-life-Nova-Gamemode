ITEM.name = "Pince"
ITEM.model = "models/props_c17/tools_pliers01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 0.500 
ITEM.class = "cityworker_pliers"
ITEM.description = [[Instrument composé de deux leviers articulés, servant à saisir et à serrer.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_PINCE -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )