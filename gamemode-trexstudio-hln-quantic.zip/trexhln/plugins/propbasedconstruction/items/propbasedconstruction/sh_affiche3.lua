ITEM.name = "Affiche de Propagande n°3"
ITEM.description = "Une affiche de propagande"
ITEM.category = "Constructable"
ITEM.model = "models/cmz/combinev4.mdl"
ITEM.prop = "models/cmz/combinev4.mdl"
ITEM.width = 2
ITEM.height = 3
