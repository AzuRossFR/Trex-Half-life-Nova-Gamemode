ITEM.name = "Kit de réparation"
ITEM.durability = 15
ITEM.quantity = 3