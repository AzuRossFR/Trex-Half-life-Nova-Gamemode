
ITEM.name = "CAB-COI Radio"
ITEM.description = "A special encrypted radio that has Union markings on it."
ITEM.frequency = "coi"
ITEM.frequencyID = "coi"
