ITEM.name = "Affiche de Propagande n°5"
ITEM.description = "Une affiche de propagande"
ITEM.category = "Constructable"
ITEM.model = "models/cmz/combinev6.mdl"
ITEM.prop = "models/cmz/combinev6.mdl"
ITEM.width = 2
ITEM.height = 3
