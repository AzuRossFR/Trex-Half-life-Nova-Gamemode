ITEM.name = "Balais"
ITEM.model = "models/nita/ph_resortmadness/broom01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 0.300 
ITEM.class = "weapon_cbroom"
ITEM.description = [[Un balai est un outil de nettoyage composé d'une longue tige avec des poils ou des brins en fibres synthétiques ou naturelles fixés à une extrémité
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_AMNESIC -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )