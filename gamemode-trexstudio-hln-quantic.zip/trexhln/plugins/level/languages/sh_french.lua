LANGUAGE = {
	level = "Niveau",
	levelXP = "Expérience: %s/%s"
}