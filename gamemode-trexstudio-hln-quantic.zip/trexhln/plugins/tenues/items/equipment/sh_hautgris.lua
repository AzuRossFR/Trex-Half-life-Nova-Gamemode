ITEM.name = "Tenue Grise"
ITEM.model = "models/props_c17/SuitCase_Passenger_Physics.mdl"
ITEM.width = 1 
ITEM.height = 1
ITEM.weight = 0.155
ITEM.description = [[Une tenue de relocalisation de couleur grise.
]]
ITEM.category = "TrexStudio"
ITEM.slot = EQUIP_SHIRT
ITEM.bodyGroups = {
    [1] = 2,
}
