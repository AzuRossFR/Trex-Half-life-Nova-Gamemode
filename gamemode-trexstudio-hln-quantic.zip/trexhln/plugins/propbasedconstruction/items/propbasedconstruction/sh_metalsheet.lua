ITEM.name = "Metal Sheet"
ITEM.description = "A Metal Sheet."
ITEM.category = "Constructable"
ITEM.model = "models/Items/item_item_crate.mdl"
ITEM.prop = "models/props_debris/metal_panel02a.mdl"
ITEM.width = 1
ITEM.height = 2
