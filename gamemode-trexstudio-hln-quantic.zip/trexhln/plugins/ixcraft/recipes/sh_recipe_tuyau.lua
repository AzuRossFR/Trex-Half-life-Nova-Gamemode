RECIPE.name = "Tuyau de métal"
RECIPE.description = "Un gros tuyau en métal, utile pour fracasser des bouches"
RECIPE.model = "models/props_canal/mattpipe.mdl"
RECIPE.category = "Armes"
RECIPE.requirements = {
	["metal"] = 8,
}
RECIPE.results = {
	["tuyau"] = 1,
}
