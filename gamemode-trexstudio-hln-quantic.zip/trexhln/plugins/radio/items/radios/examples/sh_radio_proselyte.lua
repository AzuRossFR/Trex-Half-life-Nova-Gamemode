
ITEM.name = "Union Proselyte Radio"
ITEM.description = "A special encrypted radio that requires a password to be used. It is dark green in color."
ITEM.frequency = "Proselyte"
ITEM.frequencyID = "freq_proselyte"
