ITEM.name = "Grenade à Gaz"
ITEM.model = "models/weapons/w_eq_flashbang.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 0.3
ITEM.class = "tfa_ins2_anm14"
ITEM.description = [[La grenade à gaz vous permet d'endormir les Classes-D ou vos ennemies.
]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_AMNESIC -- SLOTS = ( EQUIP_MASK EQUIP_HEAD EQUIP_LEGS EQUIP_HANDS EQUIP_TORSO )



