ITEM.name = "Sac Tactique"
ITEM.description = [[Un sac tactique qui vous permettra de stocker des objets en plus grand nombre.
]]
ITEM.model = "models/eft_props/gear/backpacks/bp_takedown_sling.mdl"
ITEM.bonemerge = "models/eft_modular/gear/backpacks/takedown_sling.mdl"
ITEM.category = "TrexSac"
ITEM.width = 2
ITEM.height = 2
ITEM.invWidth = 4
ITEM.invHeight = 2
ITEM.rarityname = "épique"
ITEM.isBag = true
ITEM.weight = 0.7
ITEM.noBusiness = true
ITEM.attachement = "hips"
ITEM.rarity = 3