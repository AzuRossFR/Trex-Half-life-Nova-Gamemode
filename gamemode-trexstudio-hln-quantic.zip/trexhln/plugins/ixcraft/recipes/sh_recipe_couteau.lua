RECIPE.name = "Couteau"
RECIPE.description = "Un couteau artisanale fabriqué à la main."
RECIPE.model = "models/weapons/tfa_nmrih/w_me_kitknife.mdl"
RECIPE.category = "Armes"
RECIPE.requirements = {
	["metal"] = 10,
	["bois"] = 3,
}
RECIPE.results = {
	["couteau"] = 1,
}
