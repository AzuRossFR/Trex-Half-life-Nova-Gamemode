--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Lettre de bienvenue";
ITEM.model = "models/dransvitry/smashinvitation/smashinvitation_gmod.mdl";
ITEM.description = "Une lettre qui contient des informations donné par un Loyaliste à l'arrivée de Cité 1.";
ITEM.bookInformation = [[
<font color='red' size='4'>Bienvenue à Cité 1.</font>

<br>
<br>

<font face='Common Sans' size='3' color='white'>
Bienvenue, bienvenue à Cité 1. Si vous êtes ici c'est que vous avez était choisi pour faire partie de notre complexe urbain de qualité. En effet c'est ici même que le traité de paix avec le Cartel à était signé le 17 mai 2000 par l'administrateur de la Terre. Le Docteur Wallace Breen.

Cette lettre vous ai destiné afin de vous apprendre les bonnes bases du bon citoyen. Alors nous vous demanderons d'être extrêment attentif et de lire correctement cette lettre qui contiendra toute les informations nécessaire à votre arrivée en cité.


<br>
<br>

[The last few pages are completely unreadable]. </font>
]];
