ITEM.name = "Taser X26"
ITEM.model = "models/sterling/enhanced_taser.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.class = "trex_tazer"
ITEM.description = [[Le Taser X26 est un pistolet à impulsion électrique utilisé à des fins de maintien de l'ordre et d'autodéfense
]]
ITEM.category = "TrexStudio"
ITEM.weight = 0.454
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_ARMES
ITEM.rarity = 1
ITEM.rarityname = "Rare (Illégal)"
