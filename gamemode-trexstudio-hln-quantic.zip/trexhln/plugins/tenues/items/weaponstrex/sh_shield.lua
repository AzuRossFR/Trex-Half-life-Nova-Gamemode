ITEM.name = "Bouclier anti-émeutes"
ITEM.model = "models/foundation/detail/crate_01.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 3.6 
ITEM.class = "tfa_l4d2mw_riotshield"
ITEM.description = [[Un bouclier antiémeute, aussi orthographié bouclier anti-émeute, est un outil léger de protection utilisé par 
les forces de l'ordre et par certaines forces armées.

]]
ITEM.category = "TrexStudio"
ITEM.bDropOnDeath = true
ITEM.slot = EQUIP_AMNESIC