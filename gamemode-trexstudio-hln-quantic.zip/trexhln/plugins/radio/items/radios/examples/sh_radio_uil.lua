
ITEM.name = "UIL Radio"
ITEM.description = "A special encrypted radio that requires a password to be used. It has a Union Innovation Labs logo on it."
ITEM.frequency = "uil"
ITEM.frequencyID = "freq_uil"
ITEM.stationaryCanAccess = false
