ITEM.name = "Radio de la protection civile"
ITEM.description = "Radio spéciale avec canal crypté et verrouillage biologique."
ITEM.category = "Communication"
ITEM.model = "models/willardnetworks/skills/handheld_radio.mdl"
ITEM.frequency = "tac"
ITEM.frequencyID = "cp_main"
ITEM.factionLock = {
	[FACTION_ADMIN_HEAD] = true,
	[FACTION_ADMIN] = true,
	[FACTION_MPF] = true,
	[FACTION_OTA] = true
}
