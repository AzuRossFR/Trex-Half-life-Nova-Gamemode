
FACTION.name = "Conseillers du Cartel"
FACTION.description = "A transhuman Overwatch soldier produced by the Combine."
FACTION.color = Color(0, 251, 255)
FACTION.pay = 40
FACTION.models = {
	{"models/echo/hla/advisor_pm.mdl",0,"0"},
}
FACTION.isDefault = false
FACTION.weapons = {"weapon_combine_advisor"}
FACTION.image = ix.util.GetMaterial("trex/bannierefaction/advisor_ban.png")
FACTION.icon = ix.util.GetMaterial("trex/logo/icon_cmb.png")
FACTION.taglines = {
	"OVERSEER",
	"VISION",
	"ALPHA"
}

function FACTION:GetDefaultName(ply)
	return "CmB:CnS°" .. string.upper(self.taglines[math.random(1, #self.taglines)]) .. "." .. Schema:ZeroNumber(math.random(10000, 99999), 5), true
end


function FACTION:OnTransferred(character)
	character:SetName(self:GetDefaultName())
	character:SetModel(self.models[1])
end

function FACTION:OnNameChanged(client, oldValue, value)
	local character = client:GetCharacter()

	if (!Schema:IsCombineRank(oldValue, "OWS") and Schema:IsCombineRank(value, "OWS")) then
		character:JoinClass(CLASS_OWS)
	elseif (!Schema:IsCombineRank(oldValue, "EOW") and Schema:IsCombineRank(value, "EOW")) then
		character:JoinClass(CLASS_EOW)
	end
end

FACTION_ADVISOR = FACTION.index
