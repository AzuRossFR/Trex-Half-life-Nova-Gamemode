ITEM.name = "Sac banane"
ITEM.description = [[Un petit sac banane qui vous permettra de stocker quelque objets.
]]
ITEM.model = "models/eft_modular/gear/backpacks/belt_bag.mdl"
ITEM.category = "TrexSac"
ITEM.width = 2
ITEM.height = 2
ITEM.invWidth = 3
ITEM.invHeight = 2
ITEM.isBag = true
ITEM.weight = 0.1
ITEM.noBusiness = true